package com.sbtraining.luvempmg.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "certifications")
public class Certification {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "certification_id")
	private Long certificationId;

    @Column(name = "certification_name")
    private String certificationName;
    
    @Column(name = "certification_level")
    private int certificationLevel;

	/**
	 * @return the certificationId
	 */
	public Long getCertificationId() {
		return certificationId;
	}

	/**
	 * @param certificationId the certificationId to set
	 */
	public void setCertificationId(Long certificationId) {
		this.certificationId = certificationId;
	}

	/**
	 * @return the certificationName
	 */
	public String getCertificationName() {
		return certificationName;
	}

	/**
	 * @param certificationName the certificationName to set
	 */
	public void setCertificationName(String certificationName) {
		this.certificationName = certificationName;
	}

	/**
	 * @return the certificationLevel
	 */
	public int getCertificationLevel() {
		return certificationLevel;
	}

	/**
	 * @param certificationLevel the certificationLevel to set
	 */
	public void setCertificationLevel(int certificationLevel) {
		this.certificationLevel = certificationLevel;
	}
 
}
