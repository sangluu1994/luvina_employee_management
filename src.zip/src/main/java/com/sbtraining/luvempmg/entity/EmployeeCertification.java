package com.sbtraining.luvempmg.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "employees_certifications")
public class EmployeeCertification {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "employee_certification_id")
	private Long employeeCertificationId;

    @Column(name = "employee_id")
    private Long employeeId;
    
    @Column(name = "certification_id")
    private Long certificationId;
    
    @Column(name = "start_date")
    private String startDate;
    
    @Column(name = "end_date")
    private String endDate;
    
    @Column(name = "score")
    private double score;

	/**
	 * @return the employeeCertificationId
	 */
	public Long getEmployeeCertificationId() {
		return employeeCertificationId;
	}

	/**
	 * @param employeeCertificationId the employeeCertificationId to set
	 */
	public void setEmployeeCertificationId(Long employeeCertificationId) {
		this.employeeCertificationId = employeeCertificationId;
	}

	/**
	 * @return the employeeId
	 */
	public Long getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the certificationId
	 */
	public Long getCertificationId() {
		return certificationId;
	}

	/**
	 * @param certificationId the certificationId to set
	 */
	public void setCertificationId(Long certificationId) {
		this.certificationId = certificationId;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the score
	 */
	public double getScore() {
		return score;
	}

	/**
	 * @param score the score to set
	 */
	public void setScore(double score) {
		this.score = score;
	}

}
