package com.sbtraining.luvempmg.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "employees")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "employee_id")
	private Long employeeId;

    @Column(name = "department_id")
    private Long departmentId;
    
    @Column(name = "employee_name")
    private String employeeName;
    
    @Column(name = "employee_name_kana")
    private String employeeNameKana;
    
    @Column(name = "employee_birth_date")
    private String employeeBirthDate;

    @Column(name = "employee_email")
    private String employeeEmail;
    
    @Column(name = "employee_telephone")
    private String employeeTelephone;
    
    @Column(name = "employee_login_id")
    private String employeeLoginId;
    
    @Column(name = "employee_login_password")
    private String employeeLoginPassword;

	/**
	 * @return the employeeId
	 */
	public Long getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the departmentId
	 */
	public Long getDepartmentId() {
		return departmentId;
	}

	/**
	 * @param departmentId the departmentId to set
	 */
	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * @return the employeeNameKana
	 */
	public String getEmployeeNameKana() {
		return employeeNameKana;
	}

	/**
	 * @param employeeNameKana the employeeNameKana to set
	 */
	public void setEmployeeNameKana(String employeeNameKana) {
		this.employeeNameKana = employeeNameKana;
	}

	/**
	 * @return the employeeBirthDate
	 */
	public String getEmployeeBirthDate() {
		return employeeBirthDate;
	}

	/**
	 * @param employeeBirthDate the employeeBirthDate to set
	 */
	public void setEmployeeBirthDate(String employeeBirthDate) {
		this.employeeBirthDate = employeeBirthDate;
	}

	/**
	 * @return the employeeEmail
	 */
	public String getEmployeeEmail() {
		return employeeEmail;
	}

	/**
	 * @param employeeEmail the employeeEmail to set
	 */
	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}

	/**
	 * @return the employeeTelephone
	 */
	public String getEmployeeTelephone() {
		return employeeTelephone;
	}

	/**
	 * @param employeeTelephone the employeeTelephone to set
	 */
	public void setEmployeeTelephone(String employeeTelephone) {
		this.employeeTelephone = employeeTelephone;
	}

	/**
	 * @return the employeeLoginId
	 */
	public String getEmployeeLoginId() {
		return employeeLoginId;
	}

	/**
	 * @param employeeLoginId the employeeLoginId to set
	 */
	public void setEmployeeLoginId(String employeeLoginId) {
		this.employeeLoginId = employeeLoginId;
	}

	/**
	 * @return the employeeLoginPassword
	 */
	public String getEmployeeLoginPassword() {
		return employeeLoginPassword;
	}

	/**
	 * @param employeeLoginPassword the employeeLoginPassword to set
	 */
	public void setEmployeeLoginPassword(String employeeLoginPassword) {
		this.employeeLoginPassword = employeeLoginPassword;
	}

}
