package com.sbtraining.luvempmg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbtraining.luvempmg.entity.Certification;
import com.sbtraining.luvempmg.repository.CertificationRepository;

@Service
public class CertificationServiceImpl implements CertificationService {

	@Autowired
	private CertificationRepository repo;

	@Override
	public List<Certification> findAll() {
		return repo.findAll();
	}

}
