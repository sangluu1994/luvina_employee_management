package com.sbtraining.luvempmg.service;

import java.util.List;

import com.sbtraining.luvempmg.entity.Certification;

public interface CertificationService {

	List<Certification> findAll();

}
