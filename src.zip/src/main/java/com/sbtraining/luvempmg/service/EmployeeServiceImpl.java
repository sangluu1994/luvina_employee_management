package com.sbtraining.luvempmg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.sbtraining.luvempmg.entity.Employee;
import com.sbtraining.luvempmg.repository.EmployeeRepository;

public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository repo;

    @Override
    public List<Employee> findAll() {
        return repo.findAll();
    }

    @Override
    public Employee findById(Long employeeId) {
        return repo.findById(employeeId).orElse(null);
    }

    @Override
    public void save(Employee employee) {
        repo.save(employee);
    }

    @Override
    public void delete(Long employeeId) {
        repo.deleteById(employeeId);
    }

}
