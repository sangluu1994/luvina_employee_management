package com.sbtraining.luvempmg.service;

import java.util.List;

import com.sbtraining.luvempmg.entity.Department;

public interface DepartmentService {

	List<Department> findAll();

}
