package com.sbtraining.luvempmg.service;

import java.util.List;

import com.sbtraining.luvempmg.entity.Employee;

public interface EmployeeService {

	public List<Employee> findAll();
	
	public Employee findById(Long employeeId);
	
	public void save(Employee employee);
	
	public void delete(Long employeeId);

}
