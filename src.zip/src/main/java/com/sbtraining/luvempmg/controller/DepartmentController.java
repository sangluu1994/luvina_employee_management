package com.sbtraining.luvempmg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.sbtraining.luvempmg.entity.Department;
import com.sbtraining.luvempmg.service.DepartmentService;

/**
 * 
 */
@Controller
public class DepartmentController {

	@Autowired
	private DepartmentService department;
	
	@GetMapping("/")
	public List<Department> findAll() {

		List<Department> listDepartment = department.findAll();
		return listDepartment;
	}

}
