package com.sbtraining.luvempmg.controller;

public class LoginController {

}
