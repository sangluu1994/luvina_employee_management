package com.sbtraining.luvempmg.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sbtraining.luvempmg.entity.Certification;

public interface CertificationRepository extends JpaRepository<Certification, Long> {

}
