package com.sbtraining.luvempmg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LuvEmployeeManageApplication {

	public static void main(String[] args) {
		SpringApplication.run(LuvEmployeeManageApplication.class, args);
	}

}
